#!/bin/sh
# Removes the brlaser filter and PPDs. Printers still using them must be removed first.
set -e

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo ./uninstall.sh" >&2
  exit 1
fi

rm -f /Library/Printers/PPDs/Contents/Resources/brlaser-*.ppd
rm -rf /Library/Printers/brlaser
echo "brlaser removed."
