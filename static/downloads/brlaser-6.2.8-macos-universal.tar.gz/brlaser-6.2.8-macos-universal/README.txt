brlaser 6.2.8 for macOS (universal: Apple Silicon + Intel, macOS 11 or later)
============================================================================

Open-source CUPS driver for Brother monochrome lasers that only speak Brother's
own language (HL-1110/1200/1210W, DCP-1510/1610W, MFC-1910W and ~100 more).

The code is not mine. It is Owl-Maintain/brlaser v6.2.8, compiled unmodified:
  https://github.com/Owl-Maintain/brlaser
  original project: https://github.com/pdewacht/brlaser

The only change is in the PPD files: the cupsFilter line points to an absolute
path, /Library/Printers/brlaser/filter/rastertobrlaser, because macOS protects
/usr/libexec/cups/filter with System Integrity Protection.

Install:    sudo ./install.sh
Uninstall:  sudo ./uninstall.sh

Build (on macOS 27, Xcode Command Line Tools, cmake):
  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
  cmake --build build
  cd build && mkdir ppd && ppdc -d ppd brlaser.drv

The binary is ad-hoc signed only (no Apple Developer ID) and not notarized.

DISCLAIMER
----------
Provided as is, without any warranty. I did not write this driver and I am not
responsible for anything it does to your printer, your Mac or your paper. You
install and run it at your own risk. If you do not trust a binary from a
stranger, build it yourself from the source included here; it takes a minute.

License: GNU GPL v2 or later (see COPYING). The complete source is included as
brlaser-6.2.8-source.tar.gz.
