#!/bin/sh
# Installs the brlaser CUPS filter and PPDs on macOS. Run with: sudo ./install.sh
set -e

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo ./install.sh" >&2
  exit 1
fi

HERE=$(cd "$(dirname "$0")" && pwd)
FILTER_DIR=/Library/Printers/brlaser/filter
PPD_DIR=/Library/Printers/PPDs/Contents/Resources

xattr -dr com.apple.quarantine "$HERE" 2>/dev/null || true

install -d -o root -g wheel -m 755 "$FILTER_DIR"
install -o root -g wheel -m 755 "$HERE/rastertobrlaser" "$FILTER_DIR/rastertobrlaser"

for ppd in "$HERE"/ppd/brlaser-*.ppd; do
  install -o root -g wheel -m 644 "$ppd" "$PPD_DIR/$(basename "$ppd")"
done

echo "Installed $FILTER_DIR/rastertobrlaser and $(ls "$HERE"/ppd/brlaser-*.ppd | wc -l | tr -d ' ') PPDs."
echo "Add the printer in System Settings > Printers & Scanners and pick the"
echo "\"<model>, using Owl-Maintain/brlaser v6.2.8\" driver under Use > Select Software."
